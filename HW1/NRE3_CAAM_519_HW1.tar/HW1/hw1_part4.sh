awk '{print $3,$4}' grades.txt
awk 'length>15' grades.txt
awk '$2 == "John"' grades.txt